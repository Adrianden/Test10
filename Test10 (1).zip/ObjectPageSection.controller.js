sap.ui.define(["sap/m/MessageToast", "sap/ui/core/mvc/Controller"], function (MessageToast, Controller) {
	"use strict";

	return Controller.extend("resume.ObjectPageSection", {
		onInit: function () {
		},
		handlePressVk        : function (oEvent) {
			window.location.href = "https://vk.com/feed";
		},
		handlePressGitHub: function (oEvent) {
			window.location.href= "https://github.com/Adrianden";
		},
		handlePressInstagram: function (oEvent) {
			window.location.href="https://www.instagram.com/adrianden5/";
		}
		
	});
}, true);
