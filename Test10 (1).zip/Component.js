sap.ui.define(["sap/ui/core/UIComponent"], function (UIComponent) {
	"use strict";

	var Component = UIComponent.extend("resume.Component", {

		metadata: {
		    manifest: "json"
		}
	});
	return Component;
}, true);
